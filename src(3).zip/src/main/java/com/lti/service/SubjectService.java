package com.lti.service;

public interface SubjectService {
	
	int getSubjectIdService(String subjectName);

}