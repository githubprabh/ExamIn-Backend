package com.lti.service;

import com.lti.dto.AdminLoginDto;

public interface AdminService {

	boolean loginAdmin(AdminLoginDto adminLoginDto);
}
