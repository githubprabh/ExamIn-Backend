package com.lti.repository;

public interface SubjectRepository {
	
	int getSubjectIdFromSubjectName(String subjectName);

}