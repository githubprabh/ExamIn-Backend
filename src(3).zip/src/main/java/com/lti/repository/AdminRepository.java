package com.lti.repository;

public interface AdminRepository {

	boolean loginAdmin(String e, String p);
}
